
const initialState = {
  list: [],
  loading: false
};

export default function taskReducer(state = initialState, action) {
  switch (action.type) {
    case "FETCH_TASKS":
      return { ...state, loading: true };
    case "FETCH_TASKS_SUCCESS":
      return { ...state, loading: false, list: action.payload };
    default:
      return state;
  }
}
