
export default function TaskDetail() {
  return (
    <div className="mobile-container">
      <h3>Shelf Replenishment</h3>
      <div className="image-placeholder">Store Image</div>
      <button className="primary-btn">Send for QC</button>
    </div>
  );
}
