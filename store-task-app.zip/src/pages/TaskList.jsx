
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function TaskList() {
  const dispatch = useDispatch();
  const tasks = useSelector((s) => s.tasks.list);

  useEffect(() => {
    dispatch({ type: "FETCH_TASKS" });
  }, []);

  return (
    <div className="mobile-container">
      <h3>Today's Tasks</h3>
      {tasks.map(t => (
        <div key={t.id} className="task-card">
          <h4>{t.title}</h4>
          <p>{t.time}</p>
        </div>
      ))}
    </div>
  );
}
