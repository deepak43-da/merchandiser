
import { Routes, Route } from "react-router-dom";
import Login from "../pages/Login";
import TaskList from "../pages/TaskList";
import TaskDetail from "../pages/TaskDetail";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/tasks" element={<TaskList />} />
      <Route path="/task/:id" element={<TaskDetail />} />
    </Routes>
  );
}
