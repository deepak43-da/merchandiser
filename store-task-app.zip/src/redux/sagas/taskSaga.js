
import { takeLatest, put } from "redux-saga/effects";

function* fetchTasksWorker() {
  yield put({
    type: "FETCH_TASKS_SUCCESS",
    payload: [
      { id: 1, title: "Shelf Replenishment", time: "10:00 - 11:00" },
      { id: 2, title: "Inventory Count", time: "02:00 - 04:00" }
    ]
  });
}

export default function* taskSaga() {
  yield takeLatest("FETCH_TASKS", fetchTasksWorker);
}
