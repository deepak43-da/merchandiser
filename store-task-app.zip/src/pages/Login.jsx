
import { useDispatch } from "react-redux";

export default function Login() {
  const dispatch = useDispatch();

  return (
    <div className="mobile-container">
      <h2>Welcome Back</h2>
      <input placeholder="Email Address" />
      <input type="password" placeholder="Password" />
      <button
        className="primary-btn"
        onClick={() => dispatch({ type: "LOGIN_REQUEST", payload: { name: "Alex" } })}
      >
        Login
      </button>
    </div>
  );
}
